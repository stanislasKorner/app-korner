Installation Korner Hub (macOS)

1. Télécharger Korner Hub.app.zip
2. Dézipper le fichier
3. Glisser “Korner Hub.app” dans le dossier Applications
4. Premier lancement :
   - clic droit sur l’app → Ouvrir
   - confirmer “Ouvrir”

